﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApplication2.Controllers
{
    public class VehicuController : ApiController
    {
        [HttpPost]
        public IHttpActionResult Add(Model.Request.VehiculoRequest model)
        {
            using(Model.GestionAutosEntities2 db = new Model.GestionAutosEntities2())
            {
                var Ovehiculo = new Model.Vehiculos();
                Ovehiculo.Nombre = model.Nombre;
                Ovehiculo.Patente = model.Patente;
                Ovehiculo.Año = model.ano;
                db.Vehiculos.Add(Ovehiculo);
                db.SaveChanges();
            }
            return Ok("Exito");
        }
    }
}
