﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApplication2.Controllers
{
    public class GestionController : ApiController
    {
        [HttpPost]
        public IHttpActionResult Add(Model.Request.GestionRequest model)
        {
            using (Model.GestionAutosEntities2 db = new Model.GestionAutosEntities2())
            {
                var OGestion = new Model.Gestion();
                OGestion.Patente = model.Patente;
                OGestion.ValorPermiso = model.ValorPermiso;
                OGestion.MontoIntereres = model.MontoIntereres;
                OGestion.MontoMulta = model.MontoMulta;
                OGestion.SubTotal = model.ValorPermiso + model.MontoIntereres + model.MontoMulta;
                OGestion.IdEstado = 1;
                OGestion.FechaRegistro = DateTime.Now;
                db.Gestion.Add(OGestion);
                db.SaveChanges();
            }
            return Ok("Exito");
        }
    }

}

