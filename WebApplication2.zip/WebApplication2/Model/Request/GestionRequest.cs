﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Model.Request
{
    public class GestionRequest
    {
        public int id { get; set; }
        public string Patente { get; set; }
        public decimal MontoIntereres { get; set; }
        public decimal MontoMulta { get; set; }
        public decimal SubTotal { get; set; }
        public decimal idEstado { get; set; }
        public decimal ValorPermiso { get; set; }
        public DateTime FechaRegistro { get; set; }
    }
}