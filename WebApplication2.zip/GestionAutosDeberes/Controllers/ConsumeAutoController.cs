﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using GestionAutosDeberes.Models.Request;

namespace GestionAutosDeberes.Controllers
{
    public class ConsumeAutoController : Controller
    {
        // GET: ConsumeAuto

        string Baseurl_ = $"https://localhost:44385/";
       
        public async Task<ActionResult> Index()
        {
            List<GestionRequest> Empinf = new List<GestionRequest>();
            using (var Client = new HttpClient())
            {
                Client.BaseAddress = new Uri(Baseurl_);
                Client.DefaultRequestHeaders.Clear();
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("Application/json"));
                HttpResponseMessage Res = await Client.GetAsync("api/Gestions");
                if(Res.IsSuccessStatusCode)
                {
                    var EndResponse = Res.Content.ReadAsStringAsync().Result;
                   Empinf = JsonConvert.DeserializeObject<List<GestionRequest>>(EndResponse);


                }
                return View(Empinf);
            }
        }

        
    }
}