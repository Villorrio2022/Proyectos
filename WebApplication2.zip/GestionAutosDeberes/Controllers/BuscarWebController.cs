﻿using GestionAutosDeberes.Models.Request;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web.Helpers;
using ChoETL;

namespace GestionAutosDeberes.Controllers
{
    public class BuscarWebController : Controller
    {

        public void Buscar(string txtPatente)
        {
            var url = $"https://localhost:44385//API/Gestions/?Patente={txtPatente}";
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.ContentType = "application/json";
            request.Accept = "application/json";

            try
            {
                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null) return;
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            // Do something with responseBody
                            // Response.Write (responseBody);
                            //serializamos el objeto

                            using (var r = ChoJSONReader.LoadText(responseBody))
                            {
                                var dt = r.AsDataTable();
                            }
                            
                        }
                    }
                }
            }
            catch (WebException ex)
            {
                // Handle error
            }
        }

     
    }

}
