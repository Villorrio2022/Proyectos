﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GestionAutosDeberes.Controllers
{
    public class PatenteController : Controller
    {
        // GET: Patente
        public ActionResult Index()
        {
            return View();
        }
    }
}