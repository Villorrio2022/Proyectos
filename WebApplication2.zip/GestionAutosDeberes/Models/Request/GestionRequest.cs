﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GestionAutosDeberes.Models.Request
{
    public class GestionRequest
    {
        public int id { get; set; }
        public string Patente { get; set; }
        public int ValorPermiso { get; set; }
        public int MontoIntereres { get; set; }
        public int MontoMulta { get; set; }
        public int SubTotal { get; set; }
        public int idEstado { get; set; }

        public DateTime FechaRegistro { get; set; }
    }
}
