﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GestionAutosDeberes.Models.Request
{
    public class GestionRequest
    {
        public int id { get; set; }
        public string Patente { get; set; }
        public double ValorPermiso { get; set; }
        public double MontoIntereres { get; set; }
        public double MontoMulta { get; set; }
        public double SubTotal { get; set; }
        public double idEstado { get; set; }

        public DateTime FechaRegistro { get; set; }
    }
}
