﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GestionAutosDeberes.Models.Request
{
    public class VehiculoRequest
    {
        public int id { get; set; }
        public string Nombre { get; set; }
        public string Patente { get; set; }
        public string ano { get; set; }
    }
}